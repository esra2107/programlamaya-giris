﻿// See https://aka.ms/new-console-template for more information

decimal anapara = 100m;
decimal faizoranı = 10m;
int gun = 10;

decimal faiz;

Console.WriteLine("anapara giriniz:");
anapara = Convert.ToDecimal(Console.ReadLine());
Console.WriteLine("faizoranı giriniz:");
faizoranı = Convert.ToDecimal(Console.ReadLine());
Console.WriteLine("gun giriniz:");
gun = Convert.ToInt32(Console.ReadLine());
faiz = anapara * faizoranı * gun/360;

Console.WriteLine("faiz" + faiz.ToString());
Console.Read();