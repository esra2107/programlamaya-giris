﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
double ortalama;
double sayi1;
double sayi2;

sayi1 = 8;
sayi2 = 10;

ortalama = (sayi1 + sayi2) / 2;

Console.WriteLine(ortalama.ToString()); 