﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//using System.Security.Cryptography;

//byte ay = Convert.ToByte(Console.ReadLine());
//switch (ay)
//{
//    case 1:
//        Console.WriteLine("Ocak");
//        break;
//    case 2:
//        Console.WriteLine("Şubat");
//        break;
//    case 3:
//        Console.WriteLine("Mart");
//        break;
//    case 4:
//        Console.WriteLine("Nisan");
//        break;
//    case 5:
//        Console.WriteLine("Mayıs");
////        break;
//    case 6:
//        Console.WriteLine("Haziran");
//        break;
//    case 7:
//        Console.WriteLine("Temmuz");
//        break;
//    case 8:
//        Console.WriteLine("Ağustos");
//        break;
//    case 9:
//        Console.WriteLine("Eylül");
//        break;
//    case 10:
//        Console.WriteLine("Ekim");
//        break;
//    case 11:
//        Console.WriteLine("Kasım");
//        break;
//    case 12:
//        Console.WriteLine("Aralık");
//        break;
//    default:
//        Console.WriteLine("1-12 arası sayı girmelisiniz!");
//        break;
//}

byte ay = Convert.ToByte(Console.ReadLine());

if (ay == 1)
{
    Console.WriteLine("Ocak");
}
else if (ay == 2)
{
    Console.WriteLine("Şubat");
}
else if (ay == 3)
{
    Console.WriteLine("Mart");
}
else if (ay == 4)
{
    Console.WriteLine("Nisan");
}
else if (ay == 5)
{
    Console.WriteLine("Mayıs");
}
else if (ay == 6)
{
    Console.WriteLine("Haziran");
}
else if (ay == 7)
{
    Console.WriteLine("Temmuz");
}
else if (ay == 8)
{
    Console.WriteLine("Ağustos");
}
else if (ay == 9)
{
    Console.WriteLine("Eylül");
}
else if (ay == 10)
{
    Console.WriteLine("Ekim");
}
else if (ay == 11)
{
    Console.WriteLine("Kasım");
}
else if (ay == 12)
{
    Console.WriteLine("Aralık");
}
else
{
    Console.WriteLine("1-12 arası sayı girmelisiniz!");
}





